
revoke all on function public.add_balance(uuid, numeric, text, text, text, jsonb) from public, anon, authenticated;
revoke all on function public.credit_earning(uuid, numeric, text, text, jsonb) from public, anon, authenticated;
revoke all on function public.handle_new_user() from public, anon, authenticated;
revoke all on function public.has_role(uuid, public.app_role) from public, anon;
grant execute on function public.has_role(uuid, public.app_role) to authenticated;
